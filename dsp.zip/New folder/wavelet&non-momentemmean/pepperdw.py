import numpy as np
import matplotlib.pyplot as plt
import cv2
from skimage import img_as_float
from skimage.restoration import denoise_nl_means, estimate_sigma
from skimage.metrics import peak_signal_noise_ratio
from skimage.util import random_noise
import imageio
from PIL import Image


original = cv2.imread('C:/Users/budit/OneDrive/Desktop/New folder/dog.jpg')
original = cv2.cvtColor(original, cv2.COLOR_BGR2RGB)
original = img_as_float(original)

noisy = random_noise(original,mode='pepper')
sigma_est = np.mean(estimate_sigma(noisy, channel_axis=-1))
patch_kw = dict(patch_size=5,patch_distance=10,  channel_axis=-1)

# slow algorithm
denoise = denoise_nl_means(noisy, h=1.15 * sigma_est,fast_mode=False,**patch_kw)

# slow algorithm, sigma provided
denoise2 = denoise_nl_means(noisy, h=0.8 * sigma_est,sigma=sigma_est,fast_mode=False, **patch_kw)

# fast algorithm
denoise_fast = denoise_nl_means(noisy, h=0.8 * sigma_est,fast_mode=True,**patch_kw)

# fast algorithm, sigma provided
denoise2_fast = denoise_nl_means(noisy, h=0.6 * sigma_est,sigma=sigma_est,fast_mode=True,**patch_kw)

psnr_noisy = peak_signal_noise_ratio(original, noisy)
psnr = peak_signal_noise_ratio(original, denoise)
psnr2 = peak_signal_noise_ratio(original, denoise2)
psnr_fast = peak_signal_noise_ratio(original, denoise_fast)
psnr2_fast = peak_signal_noise_ratio(original, denoise2_fast)

plt.subplot(4, 3, 1)
plt.title('Original Image')
plt.imshow((original))

plt.subplot(4, 3, 2)
plt.title(f'Pepper Noisy Image\nPSNR= {psnr_noisy}')
x=noisy
x = Image.fromarray((x * 255).astype(np.uint8))
imageio.imwrite("C:/Users/budit/OneDrive/Desktop/New folder/wavelet&non-momentemmean/PN/dognoise.jpg", x)
plt.imshow(x)

plt.subplot(4, 3, 3)
plt.title(f'non-local means(slow)\nPSNR= {psnr}')
x=denoise
x = Image.fromarray((x * 255).astype(np.uint8))
imageio.imwrite("C:/Users/budit/OneDrive/Desktop/New folder/wavelet&non-momentemmean/PN/dogdenoise.jpg", x)
plt.imshow(x)

plt.subplot(4, 3, 4)
plt.title('non-local means(slow, using $\\sigma_{est}$)\nPSNR='+str(psnr2))
x=denoise2
x = Image.fromarray((x * 255).astype(np.uint8))
imageio.imwrite("C:/Users/budit/OneDrive/Desktop/New folder/wavelet&non-momentemmean/PN/dogdenoise2.jpg", x)
plt.imshow(x)

plt.subplot(4, 3, 5)
plt.title('non-local means(fast)\nPSNR='+str(psnr_fast))
x=denoise_fast
x = Image.fromarray((x * 255).astype(np.uint8))
imageio.imwrite("C:/Users/budit/OneDrive/Desktop/New folder/wavelet&non-momentemmean/PN/dogfast.jpg", x)
plt.imshow(x)

plt.subplot(4, 3, 6)
plt.title('non-local means(fast, using $\\sigma_{est}$)\nPSNR='+str(psnr2_fast))
x=denoise2_fast
x = Image.fromarray((x * 255).astype(np.uint8))
imageio.imwrite("C:/Users/budit/OneDrive/Desktop/New folder/wavelet&non-momentemmean/PN/dogfast2.jpg", x)
plt.imshow(x)

original = cv2.imread('C:/Users/budit/OneDrive/Desktop/New folder/cat.jpg')
original = cv2.cvtColor(original, cv2.COLOR_BGR2RGB)
original = img_as_float(original)

sigma = 0.12
noisy = random_noise(original,var=sigma**2)
sigma_est = np.mean(estimate_sigma(noisy, channel_axis=-1))
patch_kw = dict(patch_size=5,patch_distance=10,  channel_axis=-1)

# slow algorithm
denoise = denoise_nl_means(noisy, h=1.15 * sigma_est,fast_mode=False,**patch_kw)

# slow algorithm, sigma provided
denoise2 = denoise_nl_means(noisy, h=0.8 * sigma_est,sigma=sigma_est,fast_mode=False, **patch_kw)

# fast algorithm
denoise_fast = denoise_nl_means(noisy, h=0.8 * sigma_est,fast_mode=True,**patch_kw)

# fast algorithm, sigma provided
denoise2_fast = denoise_nl_means(noisy, h=0.6 * sigma_est,sigma=sigma_est,fast_mode=True,**patch_kw)

psnr_noisy = peak_signal_noise_ratio(original, noisy)
psnr = peak_signal_noise_ratio(original, denoise)
psnr2 = peak_signal_noise_ratio(original, denoise2)
psnr_fast = peak_signal_noise_ratio(original, denoise_fast)
psnr2_fast = peak_signal_noise_ratio(original, denoise2_fast)

plt.subplot(4, 3, 7)
plt.title('Original Image')
plt.imshow((original))

plt.subplot(4, 3, 8)
plt.title(f'Pepper Noisy Image\nPSNR= {psnr_noisy}')
x=noisy
x = Image.fromarray((x * 255).astype(np.uint8))
imageio.imwrite("C:/Users/budit/OneDrive/Desktop/New folder/wavelet&non-momentemmean/PN/catnoise.jpg", x)
plt.imshow(x)

plt.subplot(4, 3, 9)
plt.title(f'non-local means(slow)\nPSNR= {psnr}')
x=denoise
x = Image.fromarray((x * 255).astype(np.uint8))
imageio.imwrite("C:/Users/budit/OneDrive/Desktop/New folder/wavelet&non-momentemmean/PN/catdenoise.jpg", x)
plt.imshow(x)

plt.subplot(4, 3, 10)
plt.title('non-local means(slow, using $\\sigma_{est}$)\nPSNR='+str(psnr2))
x=denoise2
x = Image.fromarray((x * 255).astype(np.uint8))
imageio.imwrite("C:/Users/budit/OneDrive/Desktop/New folder/wavelet&non-momentemmean/PN/catdenoise2.jpg", x)
plt.imshow(x)

plt.subplot(4, 3, 11)
plt.title('non-local means(fast)\nPSNR='+str(psnr_fast))
x=denoise_fast
x = Image.fromarray((x * 255).astype(np.uint8))
imageio.imwrite("C:/Users/budit/OneDrive/Desktop/New folder/wavelet&non-momentemmean/PN/catfast.jpg", x)
plt.imshow(x)

plt.subplot(4, 3, 12)
plt.title('non-local means(fast, using $\\sigma_{est}$)\nPSNR='+str(psnr2_fast))
x=denoise_fast
x = Image.fromarray((x * 255).astype(np.uint8))
imageio.imwrite("C:/Users/budit/OneDrive/Desktop/New folder/wavelet&non-momentemmean/PN/catfast2.jpg", x)
plt.imshow(x)
plt.show()