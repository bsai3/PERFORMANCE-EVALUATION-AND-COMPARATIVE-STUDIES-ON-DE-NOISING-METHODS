from skimage.metrics import structural_similarity
import cv2
def structural_sim(img1, img2):
  sim, diff = structural_similarity(img1, img2, full=True)
  return sim

img00 = cv2.imread("C:/Users/budit/OneDrive/Desktop/New folder/cat.jpg", 0)
img01 = cv2.imread("C:/Users/budit/OneDrive/Desktop/New folder/wavelet&non-momentemmean/PN/catfast2.jpg", 0)

ssim = structural_sim(img00, img01)
print("Similarity using SSIM is: ", ssim)