import cv2
import numpy as np
import matplotlib.pyplot as plt
from skimage.util import random_noise
from skimage.metrics import peak_signal_noise_ratio
import imageio
from PIL import Image

original = cv2.imread('C:/Users/budit/OneDrive/Desktop/New folder/dog.jpg')
original=np.squeeze(original)
sigma=0.12
noisy = random_noise(original,var=sigma**2)
noisy=np.float32(noisy)
filter_size = 3
mean_filtered_image = cv2.blur(noisy, (filter_size, filter_size))
median_filtered_image = cv2.medianBlur(noisy, filter_size)

psnr_noisy = peak_signal_noise_ratio(original, noisy)
psnr_mean = peak_signal_noise_ratio(original, mean_filtered_image)
psnr_median = peak_signal_noise_ratio(original, median_filtered_image)


plt.subplot(2, 4, 1)
plt.title('Original Image')
plt.imshow(cv2.cvtColor(original, cv2.COLOR_BGR2RGB))

plt.subplot(2, 4, 2)
plt.title(f'Gaussion Noisy Image\nPSNR= {psnr_noisy}')
x=cv2.cvtColor(noisy, cv2.COLOR_BGR2RGB)
x = Image.fromarray((x * 255).astype(np.uint8))
imageio.imwrite("C:/Users/budit/OneDrive/Desktop/New folder/meanandmedian/GN/dognoise.jpg", x)
plt.imshow(x)

plt.subplot(2, 4, 3)
plt.title(f'Mean Filtered Image\nPSNR= {psnr_mean}')
x=cv2.cvtColor(mean_filtered_image, cv2.COLOR_BGR2RGB)
x = Image.fromarray((x * 255).astype(np.uint8))
imageio.imwrite("C:/Users/budit/OneDrive/Desktop/New folder/meanandmedian/GN/dogmean_filtered_image.jpg", x)
plt.imshow(x)

plt.subplot(2, 4, 4)
plt.title(f'Median Filtered Image\nPSNR= {psnr_median}')
x=cv2.cvtColor(median_filtered_image, cv2.COLOR_BGR2RGB)
x = Image.fromarray((x * 255).astype(np.uint8))
imageio.imwrite("C:/Users/budit/OneDrive/Desktop/New folder/meanandmedian/GN/dogmedian_filtered_image.jpg", x)
plt.imshow(x)







original = cv2.imread('C:/Users/budit/OneDrive/Desktop/New folder/cat.jpg')
sigma=0.12
noisy = random_noise(original,var=sigma**2)
noisy=np.float32(noisy)
filter_size = 3
mean_filtered_image = cv2.blur(noisy, (filter_size, filter_size))
median_filtered_image = cv2.medianBlur(noisy, filter_size)

psnr_noisy = peak_signal_noise_ratio(original, noisy)
psnr_mean = peak_signal_noise_ratio(original, mean_filtered_image)
psnr_median = peak_signal_noise_ratio(original, median_filtered_image)

plt.subplot(2, 4, 5)
plt.title('Original Image')
plt.imshow(cv2.cvtColor(original, cv2.COLOR_BGR2RGB))

plt.subplot(2, 4, 6)
plt.title(f'Gaussion Noisy Image\nPSNR= {psnr_noisy}')
x=cv2.cvtColor(noisy, cv2.COLOR_BGR2RGB)
x = Image.fromarray((x * 255).astype(np.uint8))
imageio.imwrite("C:/Users/budit/OneDrive/Desktop/New folder/meanandmedian/GN/catnoise.jpg", x)
plt.imshow(x)

plt.subplot(2, 4, 7)
plt.title(f'Mean Filtered Image\nPSNR= {psnr_mean}')
x=cv2.cvtColor(mean_filtered_image, cv2.COLOR_BGR2RGB)
x = Image.fromarray((x * 255).astype(np.uint8))
imageio.imwrite("C:/Users/budit/OneDrive/Desktop/New folder/meanandmedian/GN/catmean_filtered_image.jpg", x)
plt.imshow(x)

plt.subplot(2, 4, 8)
plt.title(f'Median Filtered Image\nPSNR= {psnr_median}')
x=cv2.cvtColor(median_filtered_image, cv2.COLOR_BGR2RGB)
x = Image.fromarray((x * 255).astype(np.uint8))
imageio.imwrite("C:/Users/budit/OneDrive/Desktop/New folder/meanandmedian/GN/catmedian_filtered_image.jpg", x)
plt.imshow(x)
plt.show()