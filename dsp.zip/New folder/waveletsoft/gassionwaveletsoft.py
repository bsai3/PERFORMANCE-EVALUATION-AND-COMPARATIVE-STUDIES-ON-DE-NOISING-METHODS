import matplotlib.pyplot as plt
import cv2
from skimage.restoration import (denoise_wavelet)
from skimage import data, img_as_float
from skimage.util import random_noise
from skimage.metrics import peak_signal_noise_ratio
import imageio
from PIL import Image
import numpy as np

original = cv2.imread('C:/Users/budit/OneDrive/Desktop/New folder/dog.jpg')
original = cv2.cvtColor(original, cv2.COLOR_BGR2RGB)
original = img_as_float(original)
sigma = 0.12
noisy = random_noise(original,var=sigma**2)
im_bayes = denoise_wavelet(noisy, channel_axis=-1, convert2ycbcr=True,method='BayesShrink', mode='soft',rescale_sigma=True)
psnr_noisy = peak_signal_noise_ratio(original, noisy)
psnr_bayes = peak_signal_noise_ratio(original, im_bayes)
plt.subplot(2, 3, 1)
plt.title('Original Image')
plt.imshow(original)
plt.subplot(2, 3, 2)
plt.title(f'Gaussion Noisy Image\nPSNR= {psnr_noisy:0.4g}')
x=noisy
x = Image.fromarray((x * 255).astype(np.uint8))
imageio.imwrite("C:/Users/budit/OneDrive/Desktop/New folder/waveletsoft/GN/dognoise.jpg", x)
plt.imshow(x)

plt.subplot(2, 3, 3)
plt.title(f'wavelet Soft denosing\nPSNR= {psnr_bayes:0.4g}')
x=im_bayes
x = Image.fromarray((x * 255).astype(np.uint8))
imageio.imwrite("C:/Users/budit/OneDrive/Desktop/New folder/waveletsoft/GN/dogs.jpg", x)
plt.imshow(x)

original = cv2.imread('C:/Users/budit/OneDrive/Desktop/New folder/cat.jpg')
original = cv2.cvtColor(original, cv2.COLOR_BGR2RGB)
original = img_as_float(original)
sigma = 0.12
noisy = random_noise(original,var=sigma**2)
im_bayes = denoise_wavelet(noisy, channel_axis=-1, convert2ycbcr=True,method='BayesShrink', mode='soft',rescale_sigma=True)
psnr_noisy = peak_signal_noise_ratio(original, noisy)
psnr_bayes = peak_signal_noise_ratio(original, im_bayes)
plt.subplot(2, 3, 4)
plt.title('Original Image')
plt.imshow(original)

plt.subplot(2, 3, 5)
plt.title('Gaussion Noisy Image')
plt.xlabel(f'PSNR= {psnr_noisy:0.4g}')
x=noisy
x = Image.fromarray((x * 255).astype(np.uint8))
imageio.imwrite("C:/Users/budit/OneDrive/Desktop/New folder/waveletsoft/GN/catnoise.jpg", x)
plt.imshow(x)

plt.subplot(2, 3, 6)
plt.title('wavelet Soft denosing')
plt.xlabel(f'PSNR= {psnr_bayes:0.4g}')
x=im_bayes
x = Image.fromarray((x * 255).astype(np.uint8))
imageio.imwrite("C:/Users/budit/OneDrive/Desktop/New folder/waveletsoft/GN/cats.jpg", x)
plt.imshow(x)
plt.show()