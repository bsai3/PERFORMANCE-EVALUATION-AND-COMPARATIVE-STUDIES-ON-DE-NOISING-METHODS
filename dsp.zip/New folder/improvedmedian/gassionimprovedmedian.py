import numpy as np
import cv2
import matplotlib.pyplot as plt
import cv2
from skimage.util import random_noise
from skimage.metrics import peak_signal_noise_ratio
import imageio
from PIL import Image


def improved_median_filter(image, kernel_size):
    result = np.zeros_like(image)
    for channel in range(image.shape[2]):
        result[:, :, channel] = cv2.medianBlur(image[:, :, channel], kernel_size)
    return result

if __name__ == "__main__":
    original = cv2.imread('C:/Users/budit/OneDrive/Desktop/New folder/dog.jpg')
    sigma = 0.12
    noisy = random_noise(original,var=sigma**2)
    noisy = np.float32(noisy)
    kernel_size = 3
    median = improved_median_filter(noisy, kernel_size)
    psnr_noisy = peak_signal_noise_ratio(original, noisy)
    psnr_median = peak_signal_noise_ratio(original, median)
    print(psnr_noisy,psnr_median)
    
    plt.subplot(2, 3, 1)
    plt.title('Original Image')
    plt.imshow(cv2.cvtColor(original, cv2.COLOR_BGR2RGB))
    
    plt.subplot(2, 3, 2)
    plt.title(f'Gaussion Noisy Image\nPSNR= {psnr_noisy}')
    x=cv2.cvtColor(noisy, cv2.COLOR_BGR2RGB)
    x = Image.fromarray((x * 255).astype(np.uint8))
    imageio.imwrite("C:/Users/budit/OneDrive/Desktop/New folder/improvedmedian/GN/dognoise.jpg", x)
    plt.imshow(x)
    
    plt.subplot(2, 3, 3)
    plt.title(f'Improved Median\nPSNR= {psnr_median}')
    x=cv2.cvtColor(median, cv2.COLOR_BGR2RGB)
    x = Image.fromarray((x * 255).astype(np.uint8))
    imageio.imwrite("C:/Users/budit/OneDrive/Desktop/New folder/improvedmedian/GN/dogimprovedmedian.jpg", x)
    plt.imshow(x)   
    
    original = cv2.imread('C:/Users/budit/OneDrive/Desktop/New folder/cat.jpg')
    sigma = 0.12
    noisy = random_noise(original,var=sigma**2)
    noisy=np.float32(noisy)
    kernel_size = 3
    median = improved_median_filter(noisy, kernel_size)
    psnr_noisy = peak_signal_noise_ratio(original, noisy)
    psnr_median = peak_signal_noise_ratio(original, median)
    
    plt.subplot(2, 3, 4)
    plt.title('Original Image')
    plt.imshow(cv2.cvtColor(original, cv2.COLOR_BGR2RGB))
    
    plt.subplot(2, 3, 5)
    plt.title('Gaussion Noisy Image')
    plt.xlabel(f'PSNR= {psnr_noisy}')
    x=cv2.cvtColor(noisy, cv2.COLOR_BGR2RGB)
    x = Image.fromarray((x * 255).astype(np.uint8))
    imageio.imwrite("C:/Users/budit/OneDrive/Desktop/New folder/improvedmedian/GN/catnoise.jpg", x)
    plt.imshow(x)    
    
    plt.subplot(2, 3, 6)
    plt.title('Improved Median')
    plt.xlabel(f'PSNR= {psnr_median}')
    x=cv2.cvtColor(median, cv2.COLOR_BGR2RGB)
    x = Image.fromarray((x * 255).astype(np.uint8))
    imageio.imwrite("C:/Users/budit/OneDrive/Desktop/New folder/improvedmedian/GN/catimprovedmedian.jpg", x)
    plt.imshow(x)     
    plt.show()
    